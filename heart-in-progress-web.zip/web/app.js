/* The browser edition uses the exact same story and state machine as WeChat. */
(() => {
  const story = window.NovelStory;
  const engine = window.NovelEngine;
  const key = 'heart-novel-v1';
  const app = document.querySelector('#app');
  const esc = value => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let state = null, unlocked = [], selected = 'ma', screen = 'home', timer, storageError = false;
  try {
    const saved = JSON.parse(localStorage.getItem(key) || '{}');
    state = engine.validate(saved.state);
    unlocked = engine.validUnlocked(saved.unlocked);
  } catch (_) { storageError = true; }
  const action = (name, text, cls = '', extra = '') => `<button class="${cls}" data-action="${name}" ${extra}>${text}</button>`;
  function notify(message) {
    const toast = document.querySelector('#toast');
    toast.textContent = message;
    toast.classList.add('visible');
    clearTimeout(timer);
    timer = setTimeout(() => toast.classList.remove('visible'), 2800);
  }
  function persist() {
    try { localStorage.setItem(key, JSON.stringify({ state, unlocked })); storageError = false; return true; }
    catch (_) { storageError = true; notify('暂时无法保存，请勿关闭页面。'); return false; }
  }
  function home() {
    const saved = state ? engine.view(state) : null;
    return `<section class="welcome"><span class="eyebrow">写给青春，也写给勇敢的你</span><span class="welcome-note">INTERACTIVE NOVEL · 互动小说</span></section>
      <section class="hero" aria-labelledby="hero-title">
        <div class="hero-copy"><span class="hero-kicker"><i></i> 星榆大学 · 秋日恋爱企划</span><h1 id="hero-title" tabindex="-1">这个秋天，<br>心动由你续写<span class="title-dot">。</span></h1><p>你是王总。是活动现场的主心骨，<br>也是某个人心里，最特别的存在。</p><div class="hero-actions">${action('routes', '开启我的故事 <span>↗</span>', 'primary')}${saved ? action('resume', `继续阅读 <span>${esc(saved.route.name)} · ${saved.ending ? '已读结局' : '第 ' + saved.chapter + ' 章'} →</span>`, 'resume') : '<span class="play-note">无需注册 · 选择后自动存档</span>'}</div><div class="hero-meta"><span>3 位男主</span><b>·</b><span>9 种结局</span><b>·</b><span>无限次心动</span></div></div>
        <div class="hero-art" aria-hidden="true"><span class="art-corner">THE FIRST PAGE<br>OF OUR STORY</span><div class="arch"><div class="sun"></div><span class="window-line vertical"></span><span class="window-line horizontal"></span><div class="hills"></div></div><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><div class="book book-one"><span>love<br>notes</span><small>AUTUMN, 2026</small></div><div class="book book-two"><span class="book-star">✧</span><span class="book-heart">♡</span><small>心动手记</small></div><div class="flower-stem"></div><span class="flower">✳︎</span><span class="art-star star-one">✦</span><span class="art-star star-two">✧</span><span class="art-script">a story waiting for you</span><span class="art-number">01</span></div>
      </section>
      <section class="encounters" aria-labelledby="boys-title"><div class="section-heading"><div><span class="eyebrow">THE LEADING BOYS</span><h2 id="boys-title">三次相遇，三种心动</h2></div><span class="section-aside">下一页，遇见那个特别的他 ↗</span></div><div class="boy-grid">${story.routes.map((r, i) => `<article class="boy-card ${r.id}"><div class="card-visual"><span class="card-number">0${i + 1}</span><span class="card-symbol">${r.icon}</span><span class="visual-lines"></span><span class="visual-caption">${['a song for you', 'through his lens', 'our own rhythm'][i]}</span></div><div class="boy-copy"><div class="boy-heading"><div><span class="route-role">${r.role}</span><h3>${r.name}</h3></div><span class="route-tag">${r.tag}</span></div><p>${r.subtitle}</p><div class="boy-bottom"><span>${['一首歌的距离', '一张照片的偏爱', '一个八拍的默契'][i]}</span>${action('encounter', '遇见他 <span>↗</span>', 'text-button', `data-route="${r.id}" aria-label="遇见${r.name}"`)}</div></div></article>`).join('')}</div></section>
      <aside class="letter-note"><span class="letter-icon">✉︎</span><div><strong>不用急着做出「正确」的选择。</strong><p>勇敢表达，慢慢靠近，或成为彼此的好朋友。每一种青春，都值得被好好收藏。</p></div><span class="note-flower" aria-hidden="true">✳︎</span></aside>`;
  }
  function routes() {
    return `<section class="route-page">${action('home', '← 返回书架', 'back-link')}<span class="eyebrow">CHOOSE YOUR FIRST ENCOUNTER</span><h1 tabindex="-1">故事，要从谁开始？</h1><p class="page-desc">不同的人，不同的相遇。让心意带你选一次。</p><div class="selection-grid" role="group" aria-label="选择男主">${story.routes.map((r, i) => `<button class="select-card ${r.id} ${selected === r.id ? 'selected' : ''}" data-action="select" data-route="${r.id}" aria-pressed="${selected === r.id}"><span class="select-top"><span>0${i + 1} / ${r.role}</span><span class="radio">${selected === r.id ? '●' : '○'}</span></span><span class="select-art" aria-hidden="true">${r.icon}</span><span class="select-name">${r.name}</span><span class="route-tag">${r.tag}</span><span class="select-sub">${r.subtitle}</span><span class="select-intro">${r.intro}</span><span class="quote">${r.quote}</span></button>`).join('')}</div><div class="begin-actions">${action('begin', '和' + story.routes.find(r => r.id === selected).name + '开启故事 <span>↗</span>', 'primary')}<span class="tiny-note">约 8 分钟一条路线 · 每次选择后自动保存进度</span></div></section>`;
  }
  function read() {
    const v = engine.view(state);
    return `<article class="reader ${v.route.id}"><div class="reader-nav">${action('home', '← 故事书架', 'back-link')}${action('save', storageError ? '重试保存' : '保存进度', 'back-link')}</div><div class="reader-banner"><span>${v.route.icon} ${v.route.name}的故事</span><span><i></i> ${v.relationship}</span></div><div class="progress" aria-label="剧情进度 ${v.progress}%"><span style="width:${v.progress}%"></span></div><span class="eyebrow">${v.ending ? 'THE END · ' + v.label : 'CHAPTER 0' + v.chapter + ' / 05'}</span><h1 tabindex="-1">${esc(v.title)}</h1>${v.ending ? '' : `<span class="location">⌖ ${esc(v.place)}</span>`}<div class="story-text">${v.paragraphs.map(p => `<p>${esc(p)}</p>`).join('')}</div>${v.ending ? `<div class="ending-stamp"><span>♡</span><strong>已收录至心动手记</strong><small>${unlocked.length} / 9 个结局</small></div><div class="ending-actions">${action('restart', '再写一种可能 ↗', 'primary')}${action('collection', '翻开心动手记', 'secondary')}${action('home', '回到故事书架', 'back-choice')}</div>` : `<div class="choice-caption"><span>轮到你了，王总。</span><small>你的回应是……</small></div><div class="choices">${v.choices.map((c, i) => action('choose', `<span class="choice-letter">${'ABC'[i]}</span><span class="choice-text">${esc(c.text)}</span><span class="choice-arrow">↗</span>`, 'choice', `data-index="${i}"`)).join('')}</div>${state.history.length ? action('back', '↶ 回到上一个选择', 'back-choice') : ''}`}</article>`;
  }
  function collection() {
    return `<section class="collection-page">${action('home', '← 返回书架', 'back-link')}<span class="eyebrow">THE MEMORIES WE KEEP</span><h1 tabindex="-1">心动手记</h1><p class="page-desc">那些走过的故事，都在这里好好保存。</p><div class="collection-count">${unlocked.length}<span>/ 9 种结局已收集</span></div><div class="memory-grid">${engine.collection(unlocked).map(group => `<section class="memory-group ${group.route.id}"><h2><span>${group.route.icon}</span>${group.route.name}</h2>${group.endings.map(e => `<div class="memory ${e.unlocked ? 'unlocked' : ''}"><span class="memory-icon">${e.unlocked ? '♡' : '◇'}</span><div><strong>${e.unlocked ? e.title : '尚未寄出的信'}</strong><small>${e.label} · ${e.unlocked ? '已解锁' : '等待你的选择'}</small></div></div>`).join('')}</section>`).join('')}</div><aside class="letter-note"><span class="letter-icon">✉︎</span><div><strong>心动没有标准答案。</strong><p>选择愿意倾听的回应，能让关系更亲近；勇敢说出心意，也许会打开新的结局。</p></div></aside><div class="begin-actions">${action('routes', '开启另一种可能 ↗', 'primary')}</div></section>`;
  }
  function render(focus = true) {
    app.innerHTML = ({ home, routes, read, collection })[screen]();
    document.querySelector('#counter').textContent = unlocked.length;
    for (const name of ['home', 'collection']) {
      const node = document.querySelector('#nav-' + name);
      const active = screen === name || (name === 'home' && screen === 'routes');
      node.classList.toggle('active', active);
      if (active) node.setAttribute('aria-current', 'page'); else node.removeAttribute('aria-current');
    }
    if (focus) { window.scrollTo(0, 0); app.querySelector('h1')?.focus({ preventScroll: true }); }
  }
  function show(next) {
    state = next;
    const v = engine.view(state);
    if (v.ending && !unlocked.includes(v.endingId)) unlocked.push(v.endingId);
    persist(); screen = 'read'; render();
  }
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-action]');
    if (!button) return;
    switch (button.dataset.action) {
      case 'home': screen = 'home'; render(); break;
      case 'routes': screen = 'routes'; render(); break;
      case 'encounter': selected = button.dataset.route; screen = 'routes'; render(); break;
      case 'select': {
        selected = button.dataset.route; render(false);
        app.querySelector(`[data-route="${selected}"]`).focus({ preventScroll: true }); break;
      }
      case 'collection': screen = 'collection'; render(); break;
      case 'begin':
        if (state && state.node !== 'ending' && !window.confirm('开始新的故事会替换当前阅读进度，已收集的结局会保留。继续吗？')) return;
        show(engine.fresh(selected)); break;
      case 'resume': if (state) show(state); break;
      case 'choose': if (screen === 'read' && state.node !== 'ending') show(engine.choose(state, Number(button.dataset.index))); break;
      case 'back': if (state) show(engine.back(state)); break;
      case 'restart': selected = state.route; screen = 'routes'; render(); break;
      case 'save': if (persist()) { render(false); notify('已保存，心动可以慢慢读。'); } break;
    }
  });
  render(false);
})();
