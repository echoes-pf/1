(function (root) {
  const story = typeof module !== 'undefined' && module.exports ? require('./story') : root.NovelStory;
  const VERSION = 1;
  const hasRoute = route => typeof route === 'string' && story.routes.some(r => r.id === route);
  function fresh(route) {
    if (!hasRoute(route)) throw new Error('Unknown route');
    return { version: VERSION, route, node: 'start', affection: 0, courage: 0, flags: [], history: [] };
  }
  function endingFor(state) {
    if (state.affection >= 8 && state.courage >= 2) return 'love';
    if (state.affection >= 5) return 'warm';
    return 'friend';
  }
  function snapshot(state) {
    return { node: state.node, affection: state.affection, courage: state.courage, flags: state.flags.slice() };
  }
  function validate(raw) {
    // Replaying the choice history validates scores, branches and flags as well as the shape.
    if (!raw || raw.version !== VERSION || !hasRoute(raw.route) || !Array.isArray(raw.history) || raw.history.length > 5) return null;
    let state = fresh(raw.route);
    for (const step of raw.history) {
      if (!step || step.node !== state.node || !Number.isInteger(step.choice)) return null;
      try { state = choose(state, step.choice); } catch (_) { return null; }
    }
    if (raw.node !== state.node || raw.affection !== state.affection || raw.courage !== state.courage || JSON.stringify(raw.flags) !== JSON.stringify(state.flags)) return null;
    return state;
  }
  function choose(state, index) {
    if (state.node === 'ending') throw new Error('The story has ended');
    const node = story.stories[state.route][state.node];
    const option = node && node.choices[index];
    if (!Number.isInteger(index) || !option) throw new Error('Invalid choice');
    return {
      version: VERSION, route: state.route, node: option.next,
      affection: state.affection + option.affection, courage: state.courage + option.courage,
      flags: option.flag ? state.flags.concat(option.flag) : state.flags.slice(),
      history: state.history.concat(Object.assign(snapshot(state), { choice: index }))
    };
  }
  function back(state) {
    if (!state.history.length) return state;
    const previous = state.history[state.history.length - 1];
    return { version: VERSION, route: state.route, node: previous.node, affection: previous.affection, courage: previous.courage, flags: previous.flags.slice(), history: state.history.slice(0, -1) };
  }
  function view(state) {
    const route = story.routes.find(r => r.id === state.route);
    const ending = state.node === 'ending';
    const node = ending ? story.stories[state.route].endings[endingFor(state)] : story.stories[state.route][state.node];
    return Object.assign({}, node, {
      route, ending, endingId: ending ? state.route + ':' + endingFor(state) : '',
      chapter: ending ? 6 : node.chapter,
      progress: ending ? 100 : (node.chapter - 1) * 20,
      relationship: state.affection >= 8 ? '心意相通' : state.affection >= 5 ? '渐渐靠近' : state.affection >= 2 ? '有点在意' : '初次心动',
      paragraphs: node.paragraphs.map(p => typeof p === 'string' ? p : state.flags.includes(p.flag) ? p.yes : p.no)
    });
  }
  function collection(unlocked) {
    return story.routes.map(route => ({ id: route.id, route, endings: Object.keys(story.stories[route.id].endings).map(key => ({
      id: route.id + ':' + key, unlocked: unlocked.includes(route.id + ':' + key),
      title: story.stories[route.id].endings[key].title, label: story.stories[route.id].endings[key].label
    })) }));
  }
  function validUnlocked(raw) {
    const keys = story.routes.flatMap(r => Object.keys(story.stories[r.id].endings).map(k => r.id + ':' + k));
    return Array.isArray(raw) ? Array.from(new Set(raw.filter(k => keys.includes(k)))) : [];
  }
  const api = { fresh, choose, back, view, validate, collection, validUnlocked, endingFor };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.NovelEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
